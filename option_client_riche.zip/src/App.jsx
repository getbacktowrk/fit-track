import React, { useState, useEffect } from "react";

export default function App() {
  // 1. Notre mémoire pour stocker les exercices
  const [exercices, setExercices] = useState([]);

  useEffect(() => {
    // 2. Remplacez ce lien par le vôtre exact (avec vos clés/headers si besoin)
    fetch("https://exercisedb.dev/api/v1/exercises")
      .then((reponse) => reponse.json())
      .then((donnees) => {
        console.log("Données reçues :", donnees);
        // 3. LA CLÉ EST ICI : On va chercher le tableau à l'intérieur de 'data' !
        setExercices(donnees.data); 
      })
      .catch((erreur) => console.log("Erreur :", erreur));
  }, []);

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif", backgroundColor: "#f4f4f9", minHeight: "100vh" }}>
      <h1 style={{ textAlign: "center", color: "#333" }}>Catalogue Fit-Track 💪</h1>
      
      {/* Si la mémoire est vide (le temps que l'API réponde) */}
      {exercices.length === 0 ? (
        <p style={{ textAlign: "center", fontSize: "18px" }}>Chargement des animations en cours...</p>
      ) : (
        /* La Grille d'exercices */
        <div style={{ display: "flex", flexWrap: "wrap", gap: "25px", justifyContent: "center" }}>
          
          {/* On boucle sur les données avec les BONS noms de variables de votre capture */}
          {exercices.map((exo) => (
            
            <div key={exo.exerciseId} style={{
              backgroundColor: "white",
              borderRadius: "15px",
              padding: "15px",
              width: "280px",
              boxShadow: "0 6px 12px rgba(0,0,0,0.1)",
              display: "flex",
              flexDirection: "column"
            }}>
              
              {/* Le fameux GIF animé ! */}
              <img 
                src={exo.gifUrl} 
                alt={exo.name} 
                style={{ width: "100%", borderRadius: "10px", backgroundColor: "#fff" }} 
              />
              
              {/* Le nom de l'exercice */}
              <h3 style={{ marginTop: "15px", color: "#e63946", textTransform: "capitalize" }}>
                {exo.name}
              </h3>
              
              {/* Le muscle cible (on prend le premier élément du tableau targetMuscles) */}
              <p style={{ margin: "5px 0", color: "#555" }}>
                <strong>Cible :</strong> <span style={{ textTransform: "capitalize" }}>{exo.targetMuscles[0]}</span>
              </p>
              
              <p style={{ margin: "5px 0 15px 0", color: "#555" }}>
                <strong>Partie du corps :</strong> <span style={{ textTransform: "capitalize" }}>{exo.bodyParts[0]}</span>
              </p>
              
              {/* Le bouton pour la suite du projet */}
              <button style={{
                marginTop: "auto",
                padding: "12px",
                backgroundColor: "#1d3557",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "14px",
                transition: "background 0.3s"
              }}
              onMouseOver={(e) => e.target.style.backgroundColor = "#457b9d"}
              onMouseOut={(e) => e.target.style.backgroundColor = "#1d3557"}
              >
                + Ajouter à ma séance
              </button>
            </div>

          ))}

        </div>
      )}
    </div>
  );
}
